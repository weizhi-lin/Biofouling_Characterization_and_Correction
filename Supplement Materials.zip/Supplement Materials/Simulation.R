## This codes include biosensing signal simulation and biofouling prediction 

library(flexclust)
library(tidyverse)
library(dplyr)
library(tidyr)
library(ggplot2)
library(Matrix)
library(lme4)
library(glmnet)
library(mgcv)
library(MASS)
library(stringr)
library(gamm4)
library(truncnorm)
library(factoextra)

## ---------Import functions--------------
set.seed(2)

source(here::here("Functions",
                  "simulation_fun.R"))
source(here::here("Functions",
                  "fit_fun.R"))
source(here::here("Functions",
                  "predict_fun.R"))

labels_method <- c("Dist",
                   "WE",
                   "KM",
                   "KMD",
                   "KMWE")
levels_method <- c("Dist",
                   "Exp(lam)",
                   "K-means",
                   "K(dist)",
                   "K(lam)")

n_knots <- 60

### ----- Parameters setting ------------

## To exam the different basis please uncomment the following
# bm_to_test<-c("ps","ps","ps","tp","tp","tp") 
# km_to_test<-c(4,5,6,4,5,6) # 10
# Npatients <- c(30,50,100,200)
# Beta_T <- c(2,2.5,5,10)

bm_to_test<-c("ps")
km_to_test<-c(5) # 10
Npatients <-c(30)
Beta_T <- c(2)

BmKm<-tibble(bm = bm_to_test,
             km = km_to_test)
# repeat the experiment reps times per patient size
reps <- 2


# Gaussian kernel width
width_range <- c(0.95,0.99,0.9)
# you may change k to change the width of the Gaussian kernel 
k<-1 

## parameters to simulate the signals 
sd_theta<-1e-2
wn_sd<-2e-2
drug_level<-0.99

voltage <- seq(-0.25,0.7,length=160)
x<-voltage
len<-length(voltage)

# simulate basis number of the functional mean 
k_mean<-5
# simulate fouling effect basis number
k_eta<-10 
## parameters to scale the simulated signals  
scale_signal <- 1/5
scale_real<-2e-08
scale_current<-c(scale_signal,scale_signal*scale_real)
k_sc<-2 #1: scale to [0,1]; 2: scale to real data scale
lambda_same<-0

spline_basis_funcr<-base_creator(k_mean,x)
spline_basis_funcr_eta<-base_creator(k_eta,x)

## adjust the electrode specific curve 
Beta_Electrode<-matrix(rnorm(3*5,0,0.1),nrow=3)
signal_electrode<-generate_signals(spline_basis_funcr,Beta_Electrode)


## index to extract coefficients from the fitted model 
mean_name<-c( "s(voltage).1", "s(voltage).2", "s(voltage).3", "s(voltage).4")

## parameter for the Gaussian kernel basis 
w <- max(voltage) - min(voltage)
w <- w/(n_knots - 1)
d <- -(w)^2/log(width_range[k])

# Optimization method 
method_m <- "REML"

## parameters for the optimization algorithm 
opt_up<-c(5,log(1e10))
opt_low<-c(0,1)

## create functional basis for model fitting 
X_b <- expand_peak_basis(x=voltage,
                         bf = exp_basis_fun,
                         n_knots = n_knots,
                         d= d/2)

## names for different prediction methods
method_names<-c("Dist", "Exp(lam)", "K-means", "K(dist)","K(lam)")



### -------Start Simulation and prediction--------

Patient_data<-vector(mode="list",
                     length=length(Npatients))


Data_Signal_Error_outofloop <-vector(mode="list",length=length(Npatients))

for(np in 1:length(Npatients)){
  
  Data_Signal_Error<-vector(mode="list",length=length(Beta_T))
  
  ## This outer loop is for testing different patient variaties 
  for(b_t in 1:length(Beta_T)){
    beta_t <- Beta_T[b_t]
    bm <- BmKm$bm[1]
    km <- BmKm$km[1]
    
    st_pre<-Sys.time()
    
    Simulation_data<-vector(mode="list",
                            length=reps)
    
    DF_prediction<-vector(mode="list",
                          length=reps)
    
    Cali_data<-vector(mode="list",
                      length=reps)
    # 
    Mean_model<-vector(mode="list",
                       length=reps)
    
    Coeff_data<-vector(mode="list",
                       length=reps)
    
    dat_error_mean <- vector(mode="list",
                             length=reps)
    
    dat_error_rmse <- vector(mode="list",
                             length=reps)
    Lambda_P_outloop <- vector(mode = 'list')
    Lambda_S_outloop <- vector(mode = 'list')
    
    
    n_patients<-Npatients[np]
    
    for(i_reps in 1:reps){
      ## ---------------------- Data Generation ------------------------------------
      st_pre_i<-Sys.time()
      SimuData<-simu_data(n_patients,
                          beta_t,
                          spline_basis_funcr,
                          spline_basis_funcr_eta,
                          k_eta,
                          sd_theta,
                          wn_sd,
                          x,
                          drug_level,
                          signal_electrode)
      
      
      SimuData<-SimuData%>%
        mutate(current = scale_current[k_sc]*current)%>%
        rename(sensor_type=sensor)%>%
        mutate(km=km,
               bm=bm)
      
      Simulation_data[[i_reps]]<-SimuData
      
      ## ---------------------  Fit the models   -------------------------------------
      
      n<-n_patients
      ids<-sample(1:n)
      n_train<-0.8*n
      n_test<-n-n_train
      
      patient_train_ind<-ids[1:n_train]
      patient_test_ind<-ids[(n_train+1):n]
      
      dat <- SimuData%>%
        mutate(replication=as.factor(replication),
               sensor_type = factor(sensor_type),
               patient=factor(patient, ordered=FALSE),
               inter_sn = interaction(sensor_type,patient))
      
      dat_train <-dat%>%
        filter(patient %in% patient_train_ind)
      dat_test <- dat%>%
        filter(patient %in% patient_test_ind)
      
      first_dat<-dat_train%>%
        filter(replication==1)
      first_dat_test<-dat_test%>%
        filter(replication==1)
      
      
      ## ---- fit model for the population -----
      mod_mean1 <- bam(current ~ s(inter_sn, bs="re") +
                         s(voltage,
                           k = km, 
                           bs = bm,
                           fx = TRUE)+
                         s(voltage,
                           by = patient,
                           k = km,
                           bs = bm,
                           m = 1,
                           id=0)+
                         s(voltage, 
                           by = sensor_type,
                           k = km, 
                           bs = bm,
                           m = 1,
                           fx = TRUE,
                           id=1)-1,
                       data=first_dat,
                       # sp = c(0,-1,-1),
                       select = TRUE,
                       control = list(nthreads=4),
                       method=method_m)
      
      
      fit <- fit_tp_lasso_p(dat_train,
                            mod_mean1,
                            bf = exp_basis_fun,
                            bm = bm,
                            method_m = method_m,
                            km = km,
                            n_knots = n_knots,
                            d = d)
      
      sp_patients <- mod_mean1$sp[2]
      sp_intersn<-mod_mean1$sp[1]
      
      smooth_terms <- mod_mean1$smooth
      n_terms <- length(smooth_terms)
      n_sensor<-length(unique(first_dat$sensor_type))
      included_labels <- vector()
      # included_labels[[1]]<-smooth_terms[[1]]$label
      included_labels[[1]]<-smooth_terms[[2]]$label
      # include sensor smoother and mean smoother
      for(i in (n_terms-n_sensor+1):(n_terms)){
        included_labels[[i+n_sensor+1-n_terms]] <- smooth_terms[[i]]$label}  
      
      pred <- predict(mod_mean1,
                      newdata = first_dat_test,
                      type = "terms",
                      term = included_labels,
                      newdata.guaranteed = T,
                      # exclude = excluded_labels,
                      re.form=NA)
      Pred <- tibble(first_dat_test,
                     value=rowSums(pred))
      
      # fit model for each new patient 
      
      fit_test <- fit_tp_lasso_new(dat_test,
                                 Pred,
                                 sp_patients,
                                 sp_intersn,
                                 bf = exp_basis_fun,
                                 bm = bm,
                                 method_m = method_m,
                                 km = km, n_knots = n_knots, d = d)
      
      Lambda_S <- vector(mode = 'list')
      ## ---- Coefficients processing (to matrix forms) ----
      coeffs_ave_train<-fit$coefs
      coeffs_ave_test<-fit_test$coefs%>%mutate(rep=as.integer(rep))
      coeffs_ave<-bind_rows(coeffs_ave_train,coeffs_ave_test)
      
      name<-unique(coeffs_ave$sensor)
      kn<-as.numeric(length(unique(coeffs_ave$knot)))
      kr<-as.numeric(length(name)*kn)
      
      coeffs_ave<-coeffs_ave%>%
        mutate(patient=as.numeric(patient))%>%
        pivot_wider(names_from = rep,values_from = value,names_prefix = "Rep")%>%
        mutate(theta12 = Rep2 - Rep1,
               theta23 = Rep3 - Rep2,
               theta13 = Rep3 - Rep1)%>%
        arrange(patient)
      
      sensor_coeff_matrix_12 <- coeffs_ave%>%
        dplyr::select(patient,knot,theta12,sensor)%>%
        mutate(sensor = as.character(sensor),
               patient = as.numeric(patient))%>%
        pivot_wider(names_from = knot,values_from = theta12)
      
      sensor_coeff_matrix_23 <- coeffs_ave%>%
        dplyr::select(patient,knot,theta23,sensor)%>%
        mutate(sensor = as.character(sensor),
               patient = as.numeric(patient))%>%
        pivot_wider(names_from = knot,values_from = theta23)
      
      sensor_coeff_matrix_13 <- coeffs_ave%>%
        dplyr::select(patient,knot,theta13,sensor)%>%
        mutate(sensor = as.character(sensor),
               patient = as.numeric(patient))%>%
        pivot_wider(names_from = knot,values_from = theta13)
      
      coeff_matrix_theta12 <- coeffs_ave%>%
        dplyr::select(patient,knot,theta12,sensor)%>%
        pivot_wider(names_from = c(sensor,knot),values_from = theta12)
      
      coeff_matrix_theta13 <- coeffs_ave%>%
        dplyr::select(patient,knot,theta13,sensor)%>%
        pivot_wider(names_from = c(sensor,knot),values_from = theta13)
      
      coeff_matrix_theta23 <- coeffs_ave%>%
        dplyr::select(patient,knot,theta23,sensor)%>%
        pivot_wider(names_from = c(sensor,knot),values_from = theta23)
      
      # ------ general term coefficients -------
      
      mean_patient_train<-fit$coefs_ref$patient%>%
        mutate(patient=as.factor(patient))%>%
        dplyr::select(-3,-5,-6)%>%
        pivot_wider(names_from =knot,values_from = value,names_prefix = "pmean_knot")
      
      
      mean_patient_test<-fit_test$coefs_ref$patient%>%
        mutate(patient=as.factor(patient))%>%
        dplyr::select(-3,-5)%>%
        pivot_wider(names_from =knot,values_from = value,names_prefix = "pmean_knot")
      
      mean_patient<-bind_rows(mean_patient_train,mean_patient_test)
      
      mean_sensor<-fit$coefs_ref$sensor%>%
        dplyr::select(-3,-5,-6)%>%
        pivot_wider(names_from =knot,values_from = value,names_prefix = "smean_knot")
      
      
      long_signals<-coeffs_ave%>%
        dplyr::select(knot,sensor,patient,Rep1)%>%
        pivot_wider(names_from = c(sensor,knot),values_from = Rep1)%>%
        mutate(mean_patient)%>%
        arrange(patient)
      
      sensor_wise_long<-coeffs_ave%>%
        dplyr::select(knot,sensor,patient,Rep1)%>%
        mutate(sensor = as.character(sensor),
               patient = as.numeric(patient))%>%
        pivot_wider(names_from = knot,values_from = Rep1,names_prefix = "knot")%>%
        merge(mean_patient,by='patient',all=TRUE) #order by patient
      # dplyr::select(colnames[c(1,2,(n_knots+3):length(colnames))],everything())
      
      ids_train<-which(coeff_matrix_theta12$patient%in%patient_train_ind)
      ids_test<-which(coeff_matrix_theta12$patient%in%patient_test_ind)
      
      
      Mean_model[[i_reps]]<-list(fit_train = fit,
                                 fit_test = fit_test)
      Coeff_data[[i_reps]]<-coeffs_ave
      ## ----  Prediction: Patient-wise ------ 
      coeff_matrix<-list(coeff_matrix_theta12,
                         coeff_matrix_theta23,
                         coeff_matrix_theta13)
      
      DF_P_r<-PredictionSignals(long_signals,
                                coeff_matrix,
                                ids_test,
                                ids_train,
                                patient_test_ind,
                                kn,
                                kr,
                                name,
                                type_str = 'Patient')
      DF_P <- DF_P_r[[1]]
      Lambda_P <- tibble(rep = 1:3, width = width_range[k],lambda = DF_P_r[[2]])
      Lambda_P_outloop[[i_reps]] <- Lambda_P
      
      Cali_P <- CalibrationSignals(DF_P,
                                   type_str = 'patient',
                                   method_names,
                                   width_range[k],
                                   len,
                                   X_b,
                                   coeffs_ave,
                                   name)
      
      ## Prediction: Sensor_wise
      DF_Stype_r <- vector(mode="list",
                           length=length(name))
      DF_Stype <- vector(mode="list",
                         length=length(name))
      
      for(si in 1:length(name)){
        sensor_wise_long_si <-sensor_wise_long%>%filter(sensor==name[si])
        sensor_wise_long_si <- sensor_wise_long_si[,-2]
        
        sensor_coeff_matrix_12_si <- coeffs_ave%>%
          dplyr::select(patient,knot,theta12,sensor)%>%
          filter(sensor==name[si])%>%
          pivot_wider(names_from = c(sensor,knot),values_from = theta12)
        sensor_coeff_matrix_23_si <- coeffs_ave%>%
          dplyr::select(patient,knot,theta23,sensor)%>%
          filter(sensor==name[si])%>%
          pivot_wider(names_from = c(sensor,knot),values_from = theta23)
        sensor_coeff_matrix_13_si <- coeffs_ave%>%
          dplyr::select(patient,knot,theta13,sensor)%>%
          filter(sensor==name[si])%>%
          pivot_wider(names_from = c(sensor,knot),values_from = theta13)
        
        sensor_matrix_si<-list(sensor_coeff_matrix_12_si,
                               sensor_coeff_matrix_23_si,
                               sensor_coeff_matrix_13_si)
        
        DF_Stype_r[[si]]<-PredictionSignals(sensor_wise_long_si,
                                            sensor_matrix_si,
                                            ids_test,
                                            ids_train,
                                            patient_test_ind,
                                            kn,
                                            kn, # if it is patient-wise descriptor then is kn*number of sensor
                                            name[si],
                                            type_str = 'Sensor')
        DF_Stype[[si]] <- DF_Stype_r[[si]][[1]]
        Lambda_S[[si]] <- tibble(sensor = name[si], rep = 1:3, width = width_range[k], lambda = DF_Stype_r[[si]][[2]])
      }
      
      Lambda_S_outloop[[i_reps]]<-Lambda_S
      
      
      DF_S <- vector(mode="list",
                     length=3)
      
      for(repi in 1:3){
        for(si in 1:length(name)){
          DF_S[[repi]]<- bind_rows(DF_S[[repi]],DF_Stype[[si]][[repi]])
        }
      }
      
      Cali_S <-CalibrationSignals(DF_S,
                                  type_str = 'sensor',
                                  method_names,
                                  width_range[k],
                                  len,
                                  X_b,
                                  coeffs_ave,
                                  name)
      
      Cali_all<-rbind(Cali_S,Cali_P)
      DF_all<-rbind(bind_rows(DF_P),bind_rows(DF_S))
      
      ## ----- save the results -----
      
      Cali_all<-Cali_all%>%
        mutate(km=km,bm=bm,beta_t = beta_t)
      
      DF_all<-DF_all%>%
        mutate(km=km,bm=bm,beta_t = beta_t)
      
      
      DF_prediction[[i_reps]]<-DF_all
      Cali_data[[i_reps]]<-Cali_all
      
      rmse_ps<-fit_eval_fun_simu(Cali_all)
      rmes_mean<-rmse_ps$out_mean
      rmes_rmse<-rmse_ps$out_rmse
      
      dat_error_mean[[i_reps]]<-tibble(rmes_mean,run = i_reps,km = km, bm=bm,beta_t = beta_t)
      dat_error_rmse[[i_reps]]<-tibble(rmes_rmse,run = i_reps,km = km, bm=bm,beta_t = beta_t)
      end_pre_i<-Sys.time()
      
      time_i <-st_pre_i - end_pre_i
      
      print(paste(i_reps,'th run of Patient',Npatients[np], ', Beta = ',beta_t, ' is done. Running time = ',time_i,sep=''))
    }
    
    
    Lambda_Electrode <- bind_rows(Lambda_S_outloop)
    Lambda_Patient <- bind_rows(Lambda_P_outloop)
    
    Patient_data<-list(Simulation_Data = Simulation_data,
                       Predicted_Coeff = DF_prediction,
                       Calibrated_Data = Cali_data,
                       Mean_Model = Mean_model,
                       Fitted_Coeff = Coeff_data,
                       Sensor_Error = bind_rows(dat_error_mean),
                       Signal_Error = bind_rows(dat_error_rmse),
                       Lambda = list(Lambda_Electrode,Lambda_Patient),
                       number_patients = np)
    
    Data_Signal_Error[[b_t]] <- Patient_data$Signal_Error
    
    end_pre<-Sys.time()
    time<-st_pre - end_pre
    
    # save(Patient_data,
    #      time,
    #      file=here::here("Results",
    #                      "Simulation_patient_variability",
    #                      paste("Simu_pop_Pvar_beta","_",beta_t*10,"_",Npatients[np],".Rdata",sep='')))

  }
  
  Data_Signal_Error_outofloop[[np]]<- bind_rows(Data_Signal_Error)
}

Signal_Error <- bind_rows(Data_Signal_Error_outofloop)

# save(Signal_Error,
#      file=here::here("Results",
#                      "Simu_Errordata_Patient.Rdata"))

# Plot the comparision among different prediction models 
# Please add filter to accommodate different simulation scenario 
p_test = unique(Signal_Error$patient)
Signal_Error%>%
  filter(patient==p_test[1])%>%
  ggplot(aes(x=method,
             y=mare)) + 
  geom_boxplot(alpha=0.8)+
  coord_cartesian(ylim = c(0.05,0.25))+
  scale_y_log10()+
  labs(x="Method",
       y="log(MARE)")+ 
  labs(fill = "Number of Patients")+
  scale_fill_brewer(palette="Set2")+
  facet_wrap(~type, nrow = 1)
