
## Data processing -----
# mean matrix
mean_matrix<-function(mean_coeff_ave,j){
  df_row<-NULL
  d1<-NULL
  for(i in j){
    d1<-subset(mean_coeff_ave, patient==i,select=value)
    d1<-unname(d1)
    ave1<-t(d1)
    df_row<-rbind(df_row,ave1)
    ave1<-NULL
  }
  patient<-j
  mean_coeff_matrix<-cbind(patient,df_row)
  colnames(mean_coeff_matrix)<-c('patient',1:4)
  return(mean_coeff_matrix)
}

# Coefficient matrix of theta --
coeff_matrix<-function(coeff_theta_ave,name,j){
  df_row<-NULL
  df_l<-NULL
  for(i in j){
    for(k in name){
      d1<-coeff_theta_ave%>%
        filter(patient==i,sensor==k)
      d1<-unname(d1$theta12)
      ave1<-t(d1)
      df_row<-cbind(df_row,ave1)
    }
    df_l<- rbind(df_l,df_row)
    df_row<-NULL
  }
  patient<-j
  df_l<-cbind(patient,df_l)
  coeff_matrix_theta<-as.data.frame(df_l) 
  return(coeff_matrix_theta)
}

## estimation 
ssq_fun <- function(par, coef_test, distance, cv_id){
  # cv_id is a list of indices
  
  ssq <- 0;
  w <- exp(-exp(par)*distance) #this can be changed later
  
  n_train <- length(cv_id[[1]]) # assumes all cv folds are the same size
  n_cv <- length(cv_id)
  for(i in 1:n_cv){
    id_test <- 1:dim(coef_test)[1]
    id_test <- id_test[-cv_id[[i]]]
    for(j in 1:n_train){
      # predict theta
      id_train <- cv_id[[i]][j]
      theta_pred <- t(coef_test[id_test,])%*%w[id_train,id_test]/sum(w[id_train,id_test])
      vec <- coef_test[id_train,] - t(theta_pred)
      ssq <- ssq + sum(vec^2)
    }
  }
  return(ssq)
}


opt_fun <- function(coef_test, mean_coef, n_folds =8, lb=0, ub=5){
  
  distance <- as.matrix(dist(mean_coef))
  
  cv_id <- vector(mode = "list",
                  length = n_folds)
  
  ids <- sample(1:nrow(coef_test))
  n_obs <- ceiling(nrow(coef_test)/n_folds)
  
  for(i in 1:n_folds){
    cv_id[[i]] <- ids[((i-1)*n_obs + 1):(i*n_obs)]
    cv_id[[i]] <- na.omit(cv_id[[i]])
  }
  
  min_fun <- function(x) ssq_fun(x, coef_test = coef_test,
                                 distance = distance,
                                 cv_id = cv_id)
  
  mid_point <- mean(ub + lb)
  
  # lam<-bobyqa(mid_point,
  #             fn = min_fun,
  #             lower = lb,
  #             upper = ub)
  
  lam <- optim(mid_point,
               fn = min_fun,
               method = "Brent",
               lower = lb,
               upper = ub)
  
  return(lam)
}



exp_basis_fun <- function(x,loc, d) exp(-(x-loc)^2/d)


expand_peak_basis <- function(x,bf, 
                              n_knots= 10,internal_knots = F,...){
  
  n_knots <- n_knots + 2*internal_knots
  
  locs <- seq(min(x), max(x), length.out = n_knots)
  
  if(internal_knots) locs <- locs[-c(1,length(locs))]
  
  X <- matrix(0, nrow = length(x),
              ncol = length(locs))
  
  for(i in 1:length(x)){
    for(j in 1:length(locs)){
      X[i,j] <- bf(x[i],locs[j],...)
    }
  }
  
  return(X)
}




## input a model, output patient-wise information: train
fit_tp_lasso_p <- function(dat, mod_mean1,
                           bf = exp_basis_fun,
                           bm = "tp",
                           method_m = "REML",
                           km = 5,
                           n_knots = 10, d= 1e-3){
  # fits the model for one patient
  
  inter_vec <- unique(dat$inter_sn)
  patient_vec<-unique(dat$patient)
  sensortype_vec<-unique(dat$sensor_type)
  n_s <- length(inter_vec)
  n_pat<-length(patient_vec)
  n_sen<-length(sensortype_vec)
  
  patient_train<-unique(dat$patient)
  
  knots_names <- 1:n_knots
  #knot 0 is the intercept term
  # knots_names_2 <-0:n_knots
  
  # fit the mean function
  first_dat <- dat%>%
    filter(replication == 1)
  
  ## extract coefficients
  Coeff_value <- unname(mod_mean1$coefficients)
  name_func <- names(mod_mean1$coefficients)
  
  coefs_mean_tib <- tibble(knot = 1:(km-1),
                           value = Coeff_value[(n_s+1):(n_s+km-1)],
                           mod_sensor = name_func[(n_s+1):(n_s+km-1)],
                           sensor = name_func[(n_s+1):(n_s+km-1)],
                           rep = 1,
                           tag = 'mean')
  
  l1 <- n_sen*n_pat+km-1+(km-1)*n_pat
  
  coefs_sensor_tib<-tibble(knot = rep(1:(km-1),n_sen),
                           value = Coeff_value[(l1+1):length(Coeff_value)],
                           mod_sensor = name_func[(l1+1):length(Coeff_value)],
                           sensor = rep(unique(dat$sensor_type),each = km-1),
                           rep = 1,
                           tag = 'sensor')
  l2<-n_sen*n_pat+km-1
  coefs_patient_tib<-tibble(knot = rep(1:(km-1),n_pat),
                            value = Coeff_value[(l2+1):l1],
                            mod_sensor = name_func[(l2+1):l1],
                            patient = rep(patient_train,each = km-1),
                            rep = 1,
                            tag = 'patient')
  
  coefs_intercept_tib<-tibble(knot = rep(1:n_sen,n_pat),
                              value = Coeff_value[1:(n_sen*n_pat)],
                              mod_sensor = name_func[1:(n_sen*n_pat)],
                              patient =  rep(patient_train,each = n_sen),
                              sensor = rep(unique(dat$sensor_type),n_pat),
                              rep = 1,
                              tag = 'intercept')
  
  Coefs_general  <- list(mean = coefs_mean_tib,
                         sensor = coefs_sensor_tib,
                         patient = coefs_patient_tib,
                         intercept = coefs_intercept_tib)
  
  # fit the peaks for each patient 
  first_dat <- first_dat %>%
    mutate(res = mod_mean1$residuals,
           mean = mod_mean1$fitted.values,
           fit = mod_mean1$fitted.values)
  
  # extract the voltage
  voltage <- first_dat%>%
    filter(inter_sn == inter_vec[[1]])
  voltage <- voltage$voltage
  
  
  X <- expand_peak_basis(x=voltage,
                         bf = bf,
                         n_knots = n_knots,
                         d= d)
  
  mods_Lasso <- vector(mode= "list",
                       length = n_pat)
  coefs <- vector(mode= "list",
                  length = n_pat) 
  pred_tib <- vector(mode= "list",
                     length = n_pat)
  
  j<-1 
  for(i in patient_train){
    P_dat <- dat%>%
      filter(patient == i)
    
    S<-unique(P_dat$sensor_type)
    R<-unique(P_dat$replication)
    
    coefs_tib_r <- vector(mode= "list",
                          length = length(R)) 
    tib_pred_r <- vector(mode= "list",
                         length = length(R))
    mod_lasso_r <- vector(mode= "list",
                          length = length(R))
    
    for(r in 1:length(R)){
      first_dat_r<-first_dat%>%
        filter(patient == i)
      
      R_dat <- P_dat %>%
        filter(patient == i,
               replication == r)%>%
        mutate(res = current - first_dat_r$fit,
               mean = first_dat_r$fit)
      
      coefs_tib <- vector(mode= "list",
                          length = length(S)) 
      
      tib_pred <- vector(mode= "list",
                         length = length(S))
      
      mods_lasso <- vector(mode= "list",
                           length =length(S))
      
      for(l in 1:length(S)){
        y <- R_dat %>% 
          filter(sensor_type==S[l]) # patient & sensor type
        y <- y$res
        mod_sen <- cv.glmnet(x= X,
                             y = y,
                             alpha = 1,
                             intercept = F)
        
        mods_lasso[[l]] <- mod_sen
        
        pred <- predict(mod_sen,
                        newx = X,
                        s = "lambda.min")
        
        tib_pred[[l]] <- R_dat%>% 
          filter(sensor_type==S[l])%>%
          mutate(pred_knot = pred)
        
        coefs_sn <- coef(mod_sen,
                         lambda = "lambda.min")
        
        # coefficients of lasso selection
        vals <- rep(0,n_knots)
        vals[coefs_sn@i] <- coefs_sn@x
        
        coefs_tib[[l]] <- tibble(knot = knots_names,
                                 value = vals,
                                 sensor = S[l],
                                 patient = i,
                                 rep = r)
      }
      mod_lasso_r[[r]] <- mods_lasso
      coefs_tib_r[[r]]<-bind_rows(coefs_tib)
      tib_pred_r[[r]]<-bind_rows(tib_pred)
    }
    coefs[[j]] <- bind_rows(coefs_tib_r)
    pred_tib[[j]] <- bind_rows(tib_pred_r)
    mods_Lasso[[j]]<-mod_lasso_r
    j<-j+1
  }
  
  result <- list(coefs_ref = Coefs_general,
                 mods_lasso = mods_Lasso,
                 coefs = bind_rows(coefs),
                 pred_tib = bind_rows(pred_tib))
  
  return(result)
}

## test data set
fit_tp_lasso_new <- function(dat_test, 
                             Pred,
                             sp_patients,
                             sp_intersn,
                             bf = exp_basis_fun,
                             bm = "ts",
                             method_m = "REML",
                             km = 5, n_knots = 10, d= 1e-3){
  
  voltage <- unique(dat_test$voltage)
  
  X <- expand_peak_basis(x=voltage,
                         bf = bf,
                         n_knots = n_knots,
                         d= d)
  n_pat<-length(unique(dat_test$patient))
  mods_Lasso <- vector(mode= "list",
                       length = n_pat)
  coefs <- vector(mode= "list",
                  length = n_pat) 
  pred_tib <- vector(mode= "list",
                     length = n_pat)
  
  patient_test<-unique(dat_test$patient)
  coefs_patient <- vector(mode= "list",
                          length = length(patient_test)) 
  coefs_intercept <- vector(mode= "list",
                            length = length(patient_test)) 
  
  # fit the mean and residual for each paitent per sensor type 
  mods_Lasso <- vector(mode= "list",
                       length = n_pat)
  coefs <- vector(mode= "list",
                  length = n_pat) 
  pred_tib <- vector(mode= "list",
                     length = n_pat)
  j<-1
  
  for(i in patient_test){
    Pred_p<-Pred%>%
      filter(patient==i)
    
    dat_test_p <- dat_test%>%
      filter(patient==i)
    
    S<-unique(dat_test_p$sensor_type)
    R<-unique(dat_test_p$replication)
    
    inter_vec <- unique(dat_test_p$inter_sn)
    n_s <- length(inter_vec)
    knots_names <- 1:n_knots
    name_mean <- c(1:(km-1))
    
    
    first_dat <- dat_test_p%>%
      filter(replication==1)%>%
      mutate(current_g = current-Pred_p$value)
    # mutate(current_g = Pred_p$value)
    
    mod_test <- bam(current_g ~s(inter_sn, bs="re")+
                      s(voltage,
                        by = patient,
                        k = km,
                        bs = bm,
                        # sp = sp_patients,
                        m = 1)-1,
                    sp = c(sp_intersn,sp_patients), # specify the smoothing par. from training 
                    data = first_dat,
                    method=method_m)
    
    name_func <- names(mod_test$coefficients)
    name_value <- unname(mod_test$coefficients)
    
    coefs_patient[[j]]<- tibble(knot = name_mean,
                                value = name_value[(n_s+1):length(name_value)],
                                sensor = name_func[(n_s+1):length(name_value)],
                                patient = i,
                                rep = 1)
    
    coefs_intercept[[j]]<- tibble(knot = 1:n_s,
                                  value = name_value[1:n_s],
                                  sensor = name_func[1:n_s],
                                  patient = i,
                                  rep = 1)
    
    
    first_dat <- first_dat%>%
      mutate(res = mod_test$residuals,
             mean = mod_test$fitted.values)
    
    coefs_tib_r <- vector(mode= "list",
                          length = length(R)) 
    
    tib_pred_r <- vector(mode= "list",
                         length = length(R))
    mod_lasso_r <- vector(mode= "list",
                          length = length(R))
    
    for(r in R){
      R_dat <- dat_test_p%>%
        filter(replication == r)%>%
        mutate(res = current - mod_test$fitted.values,
               mean = mod_test$fitted.values)
      
      coefs_tib <- vector(mode= "list",
                          length = length(S)) 
      
      tib_pred <- vector(mode= "list",
                         length = length(S))
      
      mods_lasso <- vector(mode= "list",
                           length =length(S))
      
      for(l in 1:length(S)){
        y <- R_dat %>% 
          filter(sensor_type==S[l]) # patient & sensor type
        y <- y$res
        
        # if(r==1){
        #   mod_sen <- cv.glmnet(x= X,
        #                        y = y,
        #                        alpha = 1,
        #                        intercept = F)
        # }else{
        #   mod_sen <- cv.glmnet(x= X,
        #                        y = y,
        #                        alpha = 1,
        #                        intercept = T)
        # }
        mod_sen <- cv.glmnet(x= X,
                             y = y,
                             alpha = 1,
                             intercept = F)
        
        mods_lasso[[l]] <- mod_sen
        
        pred <- predict(mod_sen,
                        newx = X,
                        s = "lambda.min")
        
        tib_pred[[l]] <- R_dat%>% 
          filter(sensor_type==S[l])%>%
          mutate(pred_knot = pred)
        
        coefs_sn <- coef(mod_sen,
                         lambda = "lambda.min")
        
        # # coefficients of lasso selection
        # vals <- rep(0,n_knots+1)
        # if(r==1){
        #   vals[coefs_sn@i] <- c(mod_test$coefficients[1],
        #                         coefs_sn@x)
        # }else{
        #   vals[coefs_sn@i] <- coefs_sn@x
        # }
        vals <- rep(0,n_knots)
        vals[coefs_sn@i] <- coefs_sn@x
        
        
        coefs_tib[[l]] <- tibble(knot = knots_names,
                                 value = vals,
                                 sensor = S[l],
                                 patient = i,
                                 rep = r)
      }
      mod_lasso_r[[r]] <- mods_lasso
      coefs_tib_r[[r]]<-bind_rows(coefs_tib)
      tib_pred_r[[r]]<-bind_rows(tib_pred)
    }
    coefs[[j]] <- bind_rows(coefs_tib_r)
    pred_tib[[j]] <- bind_rows(tib_pred_r)
    mods_Lasso[[j]]<-mod_lasso_r
    j <- j+1
  }
  
  result <- list(coefs_ref = list(patient = bind_rows(coefs_patient),
                                  intercept = bind_rows(coefs_intercept)),
                 mods_lasso = mods_Lasso,
                 coefs = bind_rows(coefs),
                 pred_tib = bind_rows(pred_tib))
  
  return(result)
}



