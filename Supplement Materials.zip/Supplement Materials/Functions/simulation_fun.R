## Simulation signals-----
base_creator<-function(k,x){
  voltage<-x
  plotting_data = data.frame(x = seq(-0.25,0.7,
                                     length=160))
  tp_basis = smoothCon(s(x,bs="ps",k=k, m=2),
                       data=plotting_data,
                       knots=NULL,absorb.cons=FALSE)[[1]]
  
  #### Extract basis functions #### 
  tp_basis_funcr = as.data.frame(tp_basis$X)
  names(tp_basis_funcr) = paste("F",1:k, sep="")
  tp_basis_funcr$x = plotting_data$x
  tp_basis_funcr$model = "Thin plate spline"
  
  spline_basis_funcr = gather(tp_basis_funcr,
                              func,value, -x,-model )
  
  names_str <- paste("F",1:k, sep="")
  return(spline_basis_funcr)
}

generate_signals<-function(basis,g){
  m_basis<-basis%>%
    pivot_wider(names_from=func,
                values_from=value)
  m<-as.matrix(m_basis[-c(1,2)])
  tfunc<-m%*%t(g)
  return(tfunc)
}

simu_data<-function(n_patients,
                    beta_t = 2,
                    spline_basis_funcr,
                    spline_basis_funcr_eta,
                    k_eta,
                    sd_theta,
                    wn_sd,
                    voltage,
                    drug_level,
                    signal_electrode){
  # shift0 = c(-1,0.5,0.5,4,2.2),
  # shift1 = c(-0.5,0,1,3,3)
  x <- voltage
  n <- n_patients
  # 
  #   shift0 = c(-1,0.5,0.5,4,2.2)
  #   shift1 = c(-0.5,0,1,3,3)
  # 
  #   # Beta12<-matrix(rtruncnorm(n*2,
  #                             # a=0, b=1,
  #                             # mean=0, sd=0.1),nrow=n)
  #   Beta12<-matrix(rbeta(n*2,3,3), nrow=n)
  #   Betas2<-matrix(rbeta(n*3,4,4),nrow=n)
  #   Betas<-cbind(Beta12,Betas2)
  
  # Betas[,4] <- 2*Betas[,4]
  #generate patient group variety
  # if(n_groups==1){
  # Betas <- t(t(Betas) + shift0)
  # }
  # else{
  # np<-n*c(0.8,0.2)
  # #   # shift is a matrix with rows for each patient
  # shift <- rbind(matrix(rep(shift0,each=np[1]),nrow=np[1]),
  #                  matrix(rep(shift1,each=np[2]),nrow=np[2]))
  # #   # shift <- shift + a*drug_level
  # Betas <- Betas + shift
  #   }
  shift <- c(-3,1,0,3,2)
  Betas<-matrix(rbeta(n*5,beta_t,beta_t),nrow=n)
  Betas[,4] <- 2*Betas[,4]
  Betas <- t(t(Betas) + shift)
  
  # First measurement 
  patient<-rep(1:n,each=160)
  meanfunc<-generate_signals(spline_basis_funcr,Betas)
  
  # Move all the signals to the origin 
  A<-matrix(apply(meanfunc,2,min),ncol=n)
  meanfunc<-sweep(meanfunc,2,A,'-')
  
  meanvalue<-c(meanfunc)
  MeanData<-data.frame(patient,
                       voltage,
                       meanvalue)
  
  k_spar<-0.7*k_eta 
  
  Mi<-matrix(0,nrow=n,
             ncol=k_eta)
  
  list_1<-list(Mi,Mi,Mi)
  list_2<-list_1
  
  for(i in 1:n){
    #initial theta12
    theta12<-rep(0,k_eta) 
    
    # determine 0 entry for each patient
    sel0<-1:k_eta
    sel<-c(c(1,2,3),sample(4:k_eta,k_spar-3))
    
    G<-1.5*rbeta(k_eta,3,3) #gamma1_i
    
    # r_type<-sort(rtruncnorm(k_eta-k_spar,
    #            a=0, b=1,
    #            mean=1, sd=3),
    # decreasing = TRUE)
    
    # same as 1000 test 
    # 
    # sel0<-1:k_eta
    # sel<-c(c(1,2),sample(3:k_eta,k_spar-2))
    # 
    # G<-1.5*rbeta(k_eta,2,2) #gamma1_i
    # 
    # r_type<-sort(rtruncnorm(k_eta-k_spar, a=0, b=1, mean=1, sd=3),decreasing = TRUE)
    
    scale_drug_type <- c(1,0.9,0.8)*drug_level #more drug more fouling
    
    for(l in 1:3){
      
      # list_1[[l]][i,]<-G+1.5*r_type[l] #simulate different sensor types
      
      list_1[[l]][i,]<-G*scale_drug_type[l]
      
      list_1[[l]][i,sel]<-0
      
      # thred<-min(abs(list_1[[l]][i,])[abs(list_1[[l]][i,])>0]) #absolute value of the smallest entry
      thred<-min(list_1[[l]][i,][list_1[[l]][i,]>0])
      idx <-sel0[!sel0 %in% sel] # non-zero entry index
      
      m_foul<-c(1,0.9,0.8)*thred #gv2 
      
      # simulate the peak vanishing
      theta12[idx]<-rtruncnorm(k_eta-k_spar,
                               a=0, b=thred,
                               mean=m_foul[l], sd=sd_theta) 
      
      # all postions shift the same degree
      theta12_shift<-rep(runif(1,min=0,
                               max=min(theta12[idx])*0.3),
                         k_eta) 
      
      
      list_2[[l]][i,]<-list_1[[l]][i,]-theta12+theta12_shift
    }
  }
  G_list<-list(list_1,list_2)
  
  # Orgnize the simulation data frame 
  df<-vector(mode="list")
  DF_s<-vector(mode="list")
  for(j in 1:3){
    sensor<-rep(j,n*160)
    patient<-rep(1:n,each=160)
    voltage<-rep(x,n)
    for(r in 1:2){
      replication<-rep(r,n*160)
      func<-generate_signals(spline_basis_funcr_eta,
                             G_list[[r]][[j]])
      
      whitenoise<-rnorm(n*160,0,0.5)*1e-1
      # whitenoise<-rnorm(n*160,0,wn_sd)
      simc<-meanfunc+func+whitenoise+signal_electrode[,j]
      # if(r==1){
      #   S<-matrix(apply(simc,2,min),ncol=n)
      #   simc<-sweep(simc,2,S,'-')
      # }
      # 
      current<-c(simc)
      DF<-data.frame(patient,sensor,replication,voltage,current)
      df[[r]]<-DF
    }
    DF_s[[j]]<-bind_rows(df)
  }
  
  SimuData<-bind_rows(DF_s)
  
  rep3<-SimuData%>%
    filter(replication==2)%>%
    mutate(replication=3)
  
  SimuData<-rbind(SimuData,rep3)
  SimuData<-SimuData%>%
    mutate(beta_t = beta_t)
  
  return(SimuData)
}




fit_eval_fun_simu <- function(dat){
  
  out_rmse <- dat%>%
    mutate(res = cali2-cur1,
           res_a = abs(res),
           cur_a = abs(cur1))%>%
    group_by(patient,
             method,
             sensor_type,
             width,
             type)%>% # scaled,run
    summarise(rmse = sqrt(mean(res^2)),
              mad = mean(abs(res)),
              mare = sum(res_a)/sum(cur_a))%>%
    ungroup()%>%
    mutate(rep=2)
  
  
  out_mean<-out_rmse%>%
    group_by(patient,
             method,
             width,
             type)%>%
    summarise(mmare = mean(mare),
              smare = sum(mare),
              mrmse = sqrt(mean(sum(rmse^2))))%>%
    ungroup()%>%
    mutate(rep=2)
  out<-list(out_mean=out_mean,out_rmse=out_rmse)
  
  return(out)
  
}
