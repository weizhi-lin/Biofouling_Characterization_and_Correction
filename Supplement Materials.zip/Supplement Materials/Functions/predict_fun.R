#Prediction and Calibration

## Data Processing for Prediction ------
cons_df <- function(df,kn,kr,name,p){
  df_k<-NULL
  df_cons<-NULL
  len<-length(p)
  for(i in 1:len){
    df_r<-NULL
    theta<-df[i,]
    patient<-rep(p[i],kr)
    knot<-rep(1:kn,length(name))
    sensor<-rep(name,each=kn)
    df_r<-data.frame(patient,sensor,knot,theta)
    df_cons<-rbind(df_cons,df_r)
  }
  return(df_cons)
}

# Without Clustering
## Method 1
df_method1_p <- function(patientInd,
                         theta_test_df_o,
                         ids_train,
                         ids_test,
                         m,test,train,name,kn,kr){
  dis_test<-m[ids_train,ids_test]
  sumdis<-1/colSums(dis_test) # scaling with the distance summation 
  sumdis<-diag(sumdis)
  theta_pre<-(train%*%dis_test)%*%sumdis # prediction of testing set
  theta_pre<-t(theta_pre)
  
  theta_pre_df_1<-cons_df(theta_pre,kn,kr,name,patientInd)
  
  label1<-rep('pred',nrow(theta_pre_df_1))
  
  theta_pre_df_1<-data.frame(theta_pre_df_1,label=label1)
  
  df_method1<-rbind(theta_pre_df_1,theta_test_df_o)
  return(df_method1)
}

## Method 2
df_method_lambda_p <- function(patientInd,theta_test_df_o,ids_train,ids_test,m,train,name,kn,kr,lambda){
  w <- exp(-exp(lambda)*m) 
  w_test <- colSums(w[ids_train,ids_test])
  theta_pre_lambda<-train%*%w[ids_train,ids_test]
  theta_pre_lambda<-t(theta_pre_lambda)
  theta_pre_lambda <- sweep(theta_pre_lambda,
                            MARGIN = 1,
                            w_test,
                            "/")
  
  theta_pre_df_lambda<-cons_df(theta_pre_lambda,kn,kr,name,patientInd)
  
  label1<-rep('pred',nrow(theta_pre_df_lambda))
  
  theta_pre_df_lambda<-data.frame(theta_pre_df_lambda,label=label1)
  
  
  
  df_method_lambda<-rbind(theta_pre_df_lambda,theta_test_df_o)
  return(df_method_lambda)
}



# with clustering
## Method 3 
df_method_mean_p<-function(patientInd,pred_test,indx_cls,theta_test_df_o,coeff_matrix_theta12,ids_train,ids_test,name,kn,kr){
  # Extract the concatenated coefficient of fouling effect theta_12
  # Predict by compute the average of the coefficients within each cluster
  lents<-length(ids_test)
  theta12_mean<-NULL
  for(i in 1:lents){
    k<-pred_test[i]
    indx<-which(indx_cls==k)
    comp<-coeff_matrix_theta12[ids_train[indx],-1] # the coefficient of training data in this cluster
    theta12<-colMeans(comp)
    theta12_mean<-rbind(theta12_mean,theta12)
  }
  
  # rownames(theta12_mean)<-ids_test
  
  # Construct the data frame of the predicted theta_12 
  theta_pre_df_1<-cons_df(theta12_mean,kn,kr,name,patientInd)
  
  label1<-rep('pred',nrow(theta_pre_df_1))
  theta_pre_df_1<-data.frame(theta_pre_df_1,label=label1)
  
  df_method_mean<-rbind(theta_pre_df_1,theta_test_df_o)
  return(df_method_mean)
}
# clusters <- kmeans(X[ids_train,], kc)
# centers<-clusters$centers
# XC<-rbind(centers,X[ids_test,])
# mc <- as.matrix(dist(XC))

## Method 4 
# weighted mean within cluster
# (pred_test,indx_cls,coeff_matrix_theta12,ids_train,ids_test,m,X,lambda,name,kn,kr)
df_method_wm_p<-function(patientInd,pred_test,indx_cls,theta_test_df_o,coeff_matrix_theta12,ids_train,ids_test,m,X,kc,name,kn,kr){
  lents<-length(ids_test)
  theta12_wm<-NULL
  for(i in 1:lents){
    k<-pred_test[i]
    indx<-which(indx_cls==k)
    comp<-X[ids_train[indx],] # mean function coefficient within this cluster
    p1<-X[ids_test[i],]
    XC<-rbind(p1,comp)
    train_theta<-coeff_matrix_theta12[ids_train[indx],-1]
    # mc <- as.matrix(dist(XC))
    # Compute the distance of the new data and the data in the training set of this cluster
    m <- as.matrix(dist(XC))
    
    dis_test<-m[-1,1]
    sumdis<-1/sum(dis_test) # scaling with the distance summation 
    theta_pre<-(t(train_theta)%*%dis_test)%*%sumdis # prediction of testing set
    theta_pre<-t(theta_pre)
    
    theta12_wm<-rbind(theta12_wm,theta_pre)
  }
  # rownames(theta12_wm)<-ids_test
  
  theta_pre_df_2<-cons_df(theta12_wm,kn,kr,name,patientInd)
  label1<-rep('pred',nrow(theta_pre_df_2))
  theta_pre_df_2<-data.frame(theta_pre_df_2,label=label1)
  
  df_method_wm<-rbind(theta_pre_df_2,theta_test_df_o)
  return(df_method_wm)
}


# Method 5
## Adjusted weighted sum
df_method_wm_lambda_p<-function(patientInd,pred_test,indx_cls,theta_test_df_o,coeff_matrix_theta12,ids_train,ids_test,m,X,lambda,name,kn,kr){
  lents<-length(ids_test)
  theta12_wm_lambda<-NULL
  for(i in 1:lents){
    k<-pred_test[i]
    indx<-which(indx_cls==k)
    comp<-X[ids_train[indx],] # mean function coefficient within this cluster
    p1<-X[ids_test[i],]
    XC<-rbind(p1,comp)
    train_theta<-coeff_matrix_theta12[ids_train[indx],-1]
    # mc <- as.matrix(dist(XC))
    # Compute the distance of the new data and the data in the training set of this cluster
    m <- as.matrix(dist(XC))
    w <- exp(-exp(lambda)*m) 
    c<- 2:(length(indx)+1)
    w_test <- sum(w[c,1])
    theta_pre_lambda<-t(train_theta)%*%w[c,1]
    theta_pre_lambda<-t(theta_pre_lambda)
    theta_pre_lambda <- sweep(theta_pre_lambda,
                              MARGIN = 1,
                              w_test,
                              "/")
    
    theta12_wm_lambda<-rbind(theta12_wm_lambda,theta_pre_lambda)
  }
  # rownames(theta12_wm_lambda)<-ids_test
  
  theta_pre_df_2<-cons_df(theta12_wm_lambda,kn,kr,name,patientInd)
  
  label1<-rep('pred',nrow(theta_pre_df_2))
  
  theta_pre_df_2<-data.frame(theta_pre_df_2,label=label1)
  
  df_method_wm_lambda<-rbind(theta_pre_df_2,theta_test_df_o)
  return(df_method_wm_lambda)
}


## wrap-up functions for prediction and calibration 

PredictionSignals<-function(descriptor,
                            coeff_matrix,
                            ids_test,
                            ids_train,
                            patient_test_ind,
                            kn,
                            kr,
                            sensor_names = name, #sensor_name
                            type_str = 'patient'){
  
  X <- descriptor[,-1]
  m <- as.matrix(dist(X))
  
  LamPatient<-c()
  
  train_indx_patient<-vector(mode="list")
  
  DF_P <- vector(mode="list",
                 length=3)
  
  for(r in 1:3){
    test<-as.matrix(coeff_matrix[[r]][ids_test,-1])
    train<-t(coeff_matrix[[r]][ids_train,-1])
    
    theta_test_df_o<-cons_df(test,
                             kn,
                             kr,
                             sensor_names,
                             patient_test_ind)
    
    label2<-rep('true',nrow(theta_test_df_o))
    theta_test_df_o<-data.frame(theta_test_df_o,label=label2)
    
    mean_coef<-X[ids_train,]
    train_theta<-t(train) #coeff_matrix_theta12[ids_train,-1]
    
    # find the optimal lambda
    opt_lam <- opt_fun(train_theta,mean_coef,n_folds =8, lb=opt_low[k_sc], ub=opt_up[k_sc])
    # opt_lam <- opt_fun(train_theta,mean_coef,n_folds =8, lb=0, ub=5)
    # opt_lam <- opt_fun(train_theta,mean_coef,n_folds =8, lb=1, ub=log(1e10))
    lambda<-opt_lam$par
    LamPatient[r]<-lambda
    
    if(r>1&lambda_same==1){
      lambda<-LamPatient[1]
    }
    
    Cn<-fviz_nbclust(X[ids_train,], kmeans, k.max=5,method = "silhouette")
    kc<-which(Cn$data$y==max(Cn$data$y))
    
    cl1 <- kcca(X[ids_train,], kc, kccaFamily("kmeans"))
    pred_train <- predict(cl1)
    pred_test <- predict(cl1, newdata=X[ids_test,]) # Cluster prediction of the test set
    indx_cls<-cl1@cluster
    
    ids_test_loop<-vector(mode="list")
    
    for(cl in 1:length(ids_test)){
      kk<-pred_test[cl]
      indx<-which(indx_cls==kk)
      ids_test_loop[[cl]]<-list(ids_test[cl],indx)
    }
    train_indx_patient[[r]]<-ids_test_loop
    
    DF_patient<-vector(mode="list")
    DF_patient[[1]]<-df_method1_p(patient_test_ind,
                                  theta_test_df_o,
                                  ids_train,
                                  ids_test,
                                  m,
                                  test,train,
                                  sensor_names,
                                  kn,
                                  kr)
    DF_patient[[2]]<-df_method_lambda_p(patient_test_ind,
                                        theta_test_df_o,
                                        ids_train,
                                        ids_test,
                                        m,
                                        train,
                                        sensor_names,kn,kr,lambda)
    DF_patient[[3]]<-df_method_mean_p(patient_test_ind,
                                      pred_test,
                                      indx_cls,
                                      theta_test_df_o,
                                      coeff_matrix[[r]],#coeff_matrix_theta12,
                                      ids_train,
                                      ids_test,
                                      sensor_names,kn,kr)
    DF_patient[[4]]<-df_method_wm_p(patient_test_ind,
                                    pred_test,
                                    indx_cls,
                                    theta_test_df_o,
                                    coeff_matrix[[r]],#coeff_matrix_theta12,
                                    ids_train,
                                    ids_test,
                                    m,
                                    X,
                                    kc,sensor_names,kn,kr)
    DF_patient[[5]]<-df_method_wm_lambda_p(patient_test_ind,
                                           pred_test,
                                           indx_cls,
                                           theta_test_df_o,
                                           coeff_matrix[[r]],#coeff_matrix_theta12,
                                           ids_train,
                                           ids_test,
                                           m,
                                           X,
                                           lambda,sensor_names,kn,kr)
    
    l<-dim(DF_patient[[1]])[1]
    method<-rep(method_names,each=l)
    DF_patient<-bind_rows(DF_patient)
    DF_patient$method<-method
    
    l2<-dim(DF_patient)[1]
    Type<-rep(type_str,l2)
    DF_patient$type<-Type
    
    RepDiff<-rep(r,l2)
    DF_patient$repdiff<-RepDiff
    # access the Gammas 
    DF_P[[r]]<-DF_patient
  }
  DF_return <- list(DF_P,LamPatient)
  return(DF_return)
}


CalibrationSignals <-function(DF_P,
                              type_str = 'patient',
                              method_names,
                              width_k,
                              len,
                              X_b,
                              coeffs_ave,
                              sensor_names = name){
  DF <- vector(mode="list")
  DF_1 <- vector(mode="list")
  DF_2 <- vector(mode="list")
  
  patient_p <- as.numeric(unique(DF_P[[1]]$patient))
  
  for(i in patient_p){
    width<-rep(width_k, len)
    
    type<-rep(type_str,len)
    for (l in 1:length(method_names)){
      method<-rep(method_names[l],len)
      
      for(j in 1:length(sensor_names)){
        #gamma
        coeff<-coeffs_ave%>%filter(patient == i,
                                   sensor==sensor_names[j])
        coeff1<-coeff$Rep1
        coeff2<-coeff$Rep2
        coeff3<-coeff$Rep3
        
        gamma1<-X_b %*% coeff1  #gamma1
        gamma2<-X_b %*% coeff2
        gamma3<-X_b %*% coeff3
        
        #replication 1's signal
        cur1<-fit_test$pred_tib%>%
          filter(patient == i,
                 replication==1,
                 sensor_type==sensor_names[j])
        df0<-cur1%>%
          dplyr::select(patient,sensor_type,voltage,mean)
        cur1<-cur1$current
        
        # replication 2's signal 
        cur2<-fit_test$pred_tib%>%
          filter(patient == i,
                 replication==2,
                 sensor_type==sensor_names[j])
        cur2<-cur2$current
        
        cur3<-fit_test$pred_tib%>%
          filter(patient == i,
                 replication==3,
                 sensor_type==sensor_names[j])
        cur3<-cur3$current
        
        ta<-DF_P[[1]]%>%
          filter(patient==i,
                 label=='pred',
                 method==method_names[l],
                 sensor==sensor_names[j],
                 repdiff==1)
        
        foul12<-X_b %*% ta$theta
        
        cali2<-cur2-foul12
        
        ta2<-DF_P[[2]]%>%
          filter(patient==i,
                 label=='pred',
                 method==method_names[l],
                 sensor==sensor_names[j],
                 repdiff==2)
        
        foul23<-X_b %*% ta2$theta
        
        cali3<-cur3-foul12-foul23
        
        ta3<-DF_P[[3]]%>%
          filter(patient==i,
                 label=='pred',
                 method==method_names[l],
                 sensor==sensor_names[j],
                 repdiff==3)
        
        foul13<-X_b %*% ta3$theta
        
        cali3w<-cur3-foul13
        
        method<-rep(method_names[l],length(cali2))
        
        df<-cbind(df0,method,width,type,
                  cur1,cur2,cur3,
                  gamma1,gamma2,gamma3,
                  foul12,foul23,foul13,
                  cali2,cali3,cali3w)
        
        DF[[j]]<-df
      }
      DF_1[[l]]<-bind_rows(DF)
    }
    DF_2[[i]]<-bind_rows(DF_1)
  }
  CaliS_patient_simu<-bind_rows(DF_2)
  return(CaliS_patient_simu)
}




